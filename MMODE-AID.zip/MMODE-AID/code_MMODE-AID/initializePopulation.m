function population = initializePopulation(popSize, minBounds, maxBounds, numVars)
% Initialize random population within bounds

    minMatrix = repmat(minBounds, popSize, 1);
    maxMatrix = repmat(maxBounds, popSize, 1);
    population = minMatrix + (maxMatrix - minMatrix) .* rand(popSize, numVars);
end