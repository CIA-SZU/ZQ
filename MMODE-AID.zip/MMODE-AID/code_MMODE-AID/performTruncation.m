function removeIdx = performTruncation(popObj, popDec, numToRemove)
% Truncate population based on diversity

    N = size(popObj, 1);
    removeIdx = false(1, N);
    
    % Calculate distance metrics
    [decDiversity, decDistances, decNeighbors] = computeDistanceMetrics(popDec);
    [objDiversity, objDistances, objNeighbors] = computeDistanceMetrics(popObj);
    
    while sum(removeIdx) < numToRemove
        remaining = find(~removeIdx);
        diversityScores = decDistances(:,1) .* prod(decDiversity,2) ./ decNeighbors + ...
                          objDistances(:,1) .* prod(objDiversity,2) ./ objNeighbors;
        
        [~, minIdx] = min(diversityScores);
        removeIdx(remaining(minIdx)) = true;
        
        % Update distance matrices
        decDiversity(minIdx,:) = [];
        decDiversity(:,minIdx) = [];
        objDiversity(minIdx,:) = [];
        objDiversity(:,minIdx) = [];
        decDistances(minIdx,:) = [];
        decDistances(:,minIdx) = [];
        objDistances(minIdx,:) = [];
        objDistances(:,minIdx) = [];
    end
end