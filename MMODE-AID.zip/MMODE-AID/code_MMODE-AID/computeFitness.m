function fitness = computeFitness(popObj, popDec)
% Compute fitness score

    N = size(popObj, 1);
    
    % Dominance relations
    dominateMatrix = false(N);
    for i = 1:N-1
        for j = i+1:N
            comparison = any(popObj(i,:) < popObj(j,:)) - any(popObj(i,:) > popObj(j,:));
            if comparison == 1
                dominateMatrix(i,j) = true;
            elseif comparison == -1
                dominateMatrix(j,i) = true;
            end
        end
    end
    
    % Calculate rawFitness(i)
    strength = sum(dominateMatrix, 2);
    rawFitness = zeros(N, 1);
    for i = 1:N
        rawFitness(i) = sum(strength(dominateMatrix(:,i)));
    end
    
    % Adaptive diversity
    diversity = computeDiversity(popObj, popDec);

    % Calculate fitnesses
    fitness = rawFitness + diversity;
end