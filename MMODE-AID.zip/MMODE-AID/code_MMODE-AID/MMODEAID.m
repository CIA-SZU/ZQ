function [finalPopulation, finalFitness] = MMODEAID(functionName, varMin, varMax, numObjectives, populationSize, maxGenerations)
% MMODE-AID - Multimodal Multiobjective Differential Evolution Algorithm Based on Adaptive Individual Diversity
% Inputs:
%   functionName    - Name of the test function (string)
%   varMin          - Lower bounds of decision variables (1 �� numVariables vector)
%   varMax          - Upper bounds of decision variables (1 �� numVariables vector)
%   numObjectives   - Number of objectives (scalar)
%   populationSize  - Population size (scalar)
%   maxGenerations  - Maximum number of generations (scalar)
%
% Outputs:
%   finalPopulation - Final population solutions (populationSize �� numVariables matrix)
%   finalFitness    - Final population fitness values (populationSize �� numObjectives matrix)

% This function is written by Qian Zhou (email: 2200271029@email.szu.edu.cn)

    % Initialize parameters
    numVariables = size(varMin, 2);
    maxEvaluations = maxGenerations * populationSize;
    % Initialize population
    population = initializePopulation(populationSize, varMin, varMax, numVariables);
    % Evaluate initial population
    currentCount = 0;
    [fitnessValues, evaluationCount] = evaluatePopulation(population, functionName, numObjectives, currentCount);

    %% Main optimization loop
    while evaluationCount <= maxEvaluations
        % Combine position and fitness
        combinedPopulation = [population, fitnessValues];
        frontNumbers = NDSort(combinedPopulation(:, numVariables+1:numVariables+numObjectives), inf);
        isParetoFront = (frontNumbers == 1)';
        % Calculate fitness
        fitnessScores = computeFitness(combinedPopulation(:, numVariables+1:numVariables+numObjectives), combinedPopulation(:, 1:numVariables));
        % Generate offspring
        offspring = generateOffspring(combinedPopulation, fitnessScores, isParetoFront, varMin, varMax, numVariables);
        % Evaluate offspring
        [offspringFitness, evaluationCount] = evaluatePopulation(offspring, functionName, numObjectives, evaluationCount);
        % Environmental selection
        combinedPopulation = environmentalSelection(...
            [combinedPopulation; [offspring, offspringFitness]], ...
            numVariables, numObjectives, populationSize);
        % Update population
        population = combinedPopulation(:, 1:numVariables);
        fitnessValues = combinedPopulation(:, numVariables+1:numVariables+numObjectives);
    end
    %% Return results
    finalFitness = combinedPopulation(:, numVariables+1:numVariables+numObjectives);
    finalPopulation = combinedPopulation(:, 1:numVariables);
end

