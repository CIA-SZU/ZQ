function Offspring = diversity_based_mutation(parents, fitnessScores, isFront, minBounds, maxBounds, numVars)
% Apply diversity-based differential evolution

    % Parameter setting
    [CR, F, proM, disM] = deal(1, 0.5, 1, 20);

    % Sort by fitness
    [~, b] = sort(fitnessScores);
    firstFrontPop = parents(b(1), 1:numVars);
    frontPop = repmat(firstFrontPop, sum(isFront), 1);
    parentPop = parents(isFront, 1:numVars);
    [popSize, ~] = size(frontPop);
    minMatrix = repmat(minBounds, popSize, 1);
    maxMatrix = repmat(maxBounds, popSize, 1);
    
    % Select parents
    idx1 = 1:popSize;
    idx2 = randperm(popSize);
    idx3 = randperm(popSize);

    % Create mutation mask
    mutationMask = rand(popSize, numVars) < CR;
    
    % Differential evolution
    Offspring = frontPop(idx1,1:numVars);
    difference = F * (parentPop(idx2,1:numVars) - parentPop(idx3,1:numVars));
    Offspring(mutationMask) = frontPop(mutationMask) + difference(mutationMask);

    % Apply bounds
    Offspring = min(max(Offspring, minMatrix), maxMatrix);

    % Polynomial mutation
    MutationProb = rand(popSize, numVars) < proM/numVars;
    mu = rand(popSize, numVars);
    
    % Case 1: mu ≤ 0.5
    temp1 = MutationProb & (mu <= 0.5);
    % Ensure bounds are respected
    delta1 = (maxMatrix(temp1)-minMatrix(temp1)) .* ...
            ((2.*mu(temp1) + (1-2.*mu(temp1)) .* ...
            (1 - (Offspring(temp1)-minMatrix(temp1))./(maxMatrix(temp1)-minMatrix(temp1))).^(disM+1)).^(1/(disM+1)) - 1);
    Offspring(temp1) = Offspring(temp1) + delta1;

    % Case 2: mu > 0.5
    temp2 = MutationProb & (mu > 0.5);
    delta2 = (maxMatrix(temp2)-minMatrix(temp2)) .* ...
            (1 - (2.*(1-mu(temp2)) + 2.*(mu(temp2)-0.5) .* ...
            (1 - (maxMatrix(temp2)-Offspring(temp2))./(maxMatrix(temp2)-minMatrix(temp2))).^(disM+1)).^(1/(disM+1)));
    Offspring(temp2) = Offspring(temp2) + delta2;
end