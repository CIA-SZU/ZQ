function [diversity, decSpaceDiversity, objSpaceDiversity] = computeDiversity(popObj, popDec)
% Compute adaptive individual diversity

    [decSpaceDiversity, decDistances, decNeighbors] = computeDistanceMetrics(popDec);
    [objSpaceDiversity, objDistances, objNeighbors] = computeDistanceMetrics(popObj);
    
    diversity = decDistances(:,1) .* prod(decSpaceDiversity, 2) ./ decNeighbors + ...
                objDistances(:,1) .* prod(objSpaceDiversity, 2) ./ objNeighbors;
end