function [diversity, distances, neighborCount] = computeDistanceMetrics(points)
% Compute distance-based metrics

    N = size(points, 1);
    pairwiseDist = pdist2(points, points);
    pairwiseDist(logical(eye(N))) = inf;
    sortedDist = sort(pairwiseDist, 2);
    
    radius = mean(sortedDist(:, min(1, size(sortedDist, 2))));
    relativeDist = min(pairwiseDist ./ radius, 1);
    neighborCount = sum(sum(relativeDist < 1)) ./ N;
    neighborCount = radius ./ neighborCount;
    
    diversity = relativeDist;
    distances = sortedDist;
end