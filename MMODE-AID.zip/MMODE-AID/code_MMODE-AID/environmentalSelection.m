function newPopulation = environmentalSelection(combinedPop, numVars, numObj, popSize)
% Environmental selection with adaptive diversity
    
    fitnessScores  = computeFitness(combinedPop(:, numVars+1:numVars+numObj), combinedPop(:, 1:numVars));
    FrontNo = NDSort(combinedPop(:, numVars+1:numVars+numObj), inf);
    isSelected = (FrontNo == 1)';

    % Adjust population size
    if sum(isSelected) < popSize
        % Select additional solutions from next fronts
        remaining = popSize - sum(isSelected);
        candidates = find(~isSelected);
        [~, sortedIdx] = sort(fitnessScores(candidates));
        isSelected(candidates(sortedIdx(1:remaining))) = true;
    elseif sum(isSelected) > popSize
        % Truncate using diversity
        toRemove = performTruncation(...
            combinedPop(isSelected, numVars+1:numVars+numObj), ...
            combinedPop(isSelected, 1:numVars), ...
            sum(isSelected) - popSize);
        selectedIdx = find(isSelected);
        isSelected(selectedIdx(toRemove)) = false;
    end
    newPopulation = combinedPop(isSelected, :);
end