function [fitness, count] = evaluatePopulation(pop, func, numObj, currentCount)
% Evaluate population fitness

    fitness = zeros(size(pop, 1), numObj);
    for i = 1:size(pop, 1)
        fitness(i,:) = feval(func, pop(i,:));
    end
    count = currentCount + size(pop, 1);
end