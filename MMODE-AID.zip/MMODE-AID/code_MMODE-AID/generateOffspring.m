function offspring = generateOffspring(parentPop, fitnessScores, isFront, minBounds, maxBounds, numVars)
% Generate offspring population

    otherPop = parentPop(~isFront, 1:numVars);
    
    % Generate offspring from front population
    frontOffspring = diversity_based_mutation(parentPop, fitnessScores, isFront, minBounds, maxBounds, numVars);
    
    % Generate offspring from remaining population
    if ~isempty(otherPop)
        otherOffspring = OperatorDE(otherPop, minBounds, maxBounds, numVars);
        offspring = [frontOffspring; otherOffspring];
    else
        offspring = frontOffspring;
    end
end